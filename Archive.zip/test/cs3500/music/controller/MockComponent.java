package cs3500.music.controller;

import java.awt.Component;

/**
 * A mock Component, for testing KeyHandler.
 */
public class MockComponent extends Component {

}
