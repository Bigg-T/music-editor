package cs3500.music.controller;

/**
 * Tracker for testing.
 */
public class Tracker  {

  StringBuilder result = new StringBuilder();

  public void add(String s)  {
    result.append(s);
  }
}
