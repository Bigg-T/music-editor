package cs3500.music.tests.view;

/**
 * .
 */
public class GuiViewTest {
}
